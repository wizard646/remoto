# Remoto — cómo se instala

Esto son 4 pasos y 5 minutos. No hace falta saber nada de programación.

---

## Antes de empezar: una advertencia honesta

Remoto envía teclas y clics a tu computadora. Para el antivirus eso se ve
**exactamente igual que un virus**, y por eso va a borrar los archivos o te
va a mostrar un aviso. No es un error del programa: es lo que hace.

**Agregá la carpeta a las excepciones del antivirus antes de seguir.**

### Bitdefender

1. Abrí **Bitdefender**
2. **Protección** → **Amenazas** → **Excepciones**
3. **Agregar carpeta** → elegí la carpeta donde dejaste Remoto
4. Aceptá

### Windows Defender

1. Abrí **Seguridad de Windows** → **Protección contra virus y amenazas**
2. **Configuración de protección** → **Excluir** → **Agregar una exclusión**
3. **Carpeta** → elegí la carpeta de Remoto

---

## Paso 1 — Descomprimir

Descomprimí el ZIP donde quieras. Por ejemplo en `C:\Remoto`.

Ojo: si Windows te dice que el archivo está bloqueado, hacé clic derecho
sobre el ZIP → **Propiedades** → abajo tildá **Desbloquear** → **Aceptar**.

## Paso 2 — Doble clic en `montar.cmd`

Aparece una ventana negra. Te va a pedir permiso de administrador: aceptá.

Está haciendo cinco cosas:

- renombra los archivos que vienen con `.txt` al final
- compila `Remoto.exe`
- le pone la firma digital
- abre el puerto 8080 en el firewall de Windows
- genera una clave de acceso

Cuando termine dice algo así:

```
  Remoto listo.
  En el celular: http://192.168.1.50:8080
  Clave: A7K2M9   (esta en clave.txt, se puede cambiar)
  Abre Remoto.exe
```

**Anotá esos dos datos**, los vas a necesitar.

## Paso 3 — Abrir `Remoto.exe`

Doble clic. Sale una ventana con la dirección y la clave.

Tocá **Iniciar**.

Se va a minimizar a la bandeja del sistema, abajo a la derecha, junto al reloj.
Ahí sigue corriendo.

## Paso 4 — En el celular

1. Instalá la app **Remoto** (si no la tenés, compilala con `npm install` y
   `npx expo start`, o pedile el APK a quien te lo pasó)
2. Abrila
3. Escribí la **dirección** de la PC (solo los números: `192.168.1.50`)
4. Escribí la **clave**
5. Tocá **Entrar**

Las dos veces te las guarda, así que la próxima solo abrís la app.

---

## Si algo no anda

| Que pasa | Que hacer |
|---|---|
| El antivirus borró los `.ps1` | Volvé a agregar la carpeta a las excepciones y corré `montar.cmd` de nuevo |
| La app dice que no entra | Verificá que la PC y el celular estén en el **mismo WiFi** |
| Sigue sin entrar | Fijate que el firewall tenga el puerto 8080 abierto, y que no haya un antivirus que lo bloquee |
| `montar.cmd` dice que no encuentra `montar.ps1` | Descomprimí el ZIP entero, no solo algunos archivos |
| La PC no aparece en la app | Encendé la PC y tocá **Iniciar** en la ventana de Remoto |
| Windows pide permiso de administrador y no lo da | Clic derecho en `montar.cmd` → **Ejecutar como administrador** |
| Te pide una clave que no es la que copiaste | Mirá `clave.txt`, adentro de la carpeta |

**El WiFi es lo más importante.** Si el celular está con datos móviles, o en
otro WiFi, no va a funcionar. Es a propósito: Remoto no sale de tu red.

---

## Que hace y que no hace

**Hace:** mover el mouse, teclas y combinaciones, volumen, portapapeles,
mandar archivos, abrir y cerrar programas, scripts con nombre, música,
capturas, apagar, reiniciar, temporizador.

**No hace:** cámara, micrófono, grabar la pantalla, ni funcionar desde
internet. Eso no está y no se puede agregar.

---

## Desinstalar

1. Cerrá `Remoto.exe` (clic derecho en el ícono de la bandeja → **Salir**)
2. Borrá la carpeta
3. Si querés quitar el puerto del firewall:
   ```powershell
   Remove-NetFirewallRule -DisplayName "Remoto"
   ```
